WEEK 6 - GENERATIVE AI PROGRAMMING PRACTICAL
Student: Tejaswini | Release: v0.1

FILES
- main.py: baseline evaluator
- golden_set.json: 30 golden questions, expected answers, keywords and sources
- requirements.txt: Python dependency
- baseline_results.csv: generated automatically after a run

SETUP IN VS CODE (WINDOWS)
1. Extract this ZIP and open the Week6_Tejaswini folder in VS Code.
2. Install Python 3 if it is not already installed.
3. Open Terminal > New Terminal.
4. Install the package:
   python -m pip install -r requirements.txt

OFFLINE DEMO (runs without Ollama):
   python main.py --demo
This uses the expected answers as sample responses to demonstrate the scoring and CSV workflow.
It is NOT a live evaluation of Llama 3.2.

LIVE LLAMA 3.2 EVALUATION:
1. Install Ollama from https://ollama.com/download
2. In PowerShell, run:
   ollama --version
   ollama pull llama3.2
3. Make sure Ollama is running.
4. Run:
   python main.py

The live run sends each golden question to the local Ollama API and scores the returned answer by keyword coverage.
The program writes baseline_results.csv in this same folder.
