import argparse
import csv
import json
import sys
from datetime import datetime
from pathlib import Path

import requests

OLLAMA_URL = "http://localhost:11434/api/generate"
MODEL_NAME = "llama3.2"
INPUT_FILE = Path(__file__).with_name("golden_set.json")
OUTPUT_FILE = Path(__file__).with_name("baseline_results.csv")
RELEASE = "v0.1"


def load_questions():
    if not INPUT_FILE.exists():
        raise FileNotFoundError(f"Could not find {INPUT_FILE.name}. Keep it beside main.py.")
    with INPUT_FILE.open("r", encoding="utf-8") as file:
        data = json.load(file)
    if not isinstance(data, list) or not data:
        raise ValueError("golden_set.json must contain a non-empty JSON list.")
    return data


def get_llm_answer(question):
    payload = {
        "model": MODEL_NAME,
        "prompt": question,
        "stream": False,
        "options": {"temperature": 0}
    }
    response = requests.post(OLLAMA_URL, json=payload, timeout=180)
    response.raise_for_status()
    answer = response.json().get("response", "").strip()
    if not answer:
        raise RuntimeError("Ollama returned an empty response.")
    return answer


def calculate_score(answer, expected_keywords):
    answer_lower = answer.lower()
    matched = [word for word in expected_keywords if word.lower() in answer_lower]
    missing = [word for word in expected_keywords if word.lower() not in answer_lower]
    score = (len(matched) / len(expected_keywords) * 100) if expected_keywords else 0
    return round(score, 2), matched, missing


def main():
    parser = argparse.ArgumentParser(description="Week 6 LLM baseline evaluator")
    parser.add_argument(
        "--demo", action="store_true",
        help="Run an offline demonstration using expected answers (does not evaluate Llama 3.2)."
    )
    args = parser.parse_args()

    try:
        questions = load_questions()
    except (OSError, json.JSONDecodeError, ValueError) as error:
        print(f"Setup error: {error}")
        return 1

    print("\n" + "=" * 58)
    print("              WEEK 6 - BASELINE EVALUATION")
    print("              Student: Tejaswini")
    print("=" * 58)
    print(f"Total Questions: {len(questions)}")
    print(f"Model: {MODEL_NAME}")
    print(f"Release: {RELEASE}")
    if args.demo:
        print("Mode: OFFLINE DEMO (expected answers are used as sample responses)")
    else:
        print("Mode: LIVE OLLAMA")
        try:
            check = requests.get("http://localhost:11434/api/tags", timeout=5)
            check.raise_for_status()
            available = [m.get("name", "") for m in check.json().get("models", [])]
            if not any(name == MODEL_NAME or name.startswith(MODEL_NAME + ":") for name in available):
                print(f"Model '{MODEL_NAME}' is not installed.")
                print("Run this command in PowerShell: ollama pull llama3.2")
                return 1
        except requests.RequestException:
            print("Cannot connect to Ollama at http://localhost:11434.")
            print("Start Ollama, then run: ollama pull llama3.2")
            print("For an offline code demonstration, run: python main.py --demo")
            return 1

    results = []
    total_score = 0.0
    successful = 0
    print("\nBASELINE RUN STARTED")
    print("-" * 58)

    for index, item in enumerate(questions, start=1):
        qid = item.get("id", f"Q{index:03d}")
        question = item["question"]
        expected = item["expected_answer"]
        keywords = item.get("keywords", [])
        source = item.get("source", "")
        print(f"\nQuestion {index}/{len(questions)}: {qid} - {question}")

        try:
            answer = expected if args.demo else get_llm_answer(question)
            score, matched, missing = calculate_score(answer, keywords)
            status = "PASS" if score >= 60 else "REVIEW"
            successful += 1
            total_score += score
            print(f"Score: {score:.2f}% | Status: {status}")
            results.append({
                "Question_ID": qid,
                "Question": question,
                "Expected_Answer": expected,
                "LLM_Answer": answer,
                "Matched_Keywords": ", ".join(matched),
                "Missing_Keywords": ", ".join(missing),
                "Score": score,
                "Status": status,
                "Source": source,
                "Model": MODEL_NAME,
                "Release": RELEASE
            })
        except (requests.RequestException, RuntimeError, ValueError) as error:
            print(f"Request failed: {error}")
            results.append({
                "Question_ID": qid,
                "Question": question,
                "Expected_Answer": expected,
                "LLM_Answer": "",
                "Matched_Keywords": "",
                "Missing_Keywords": ", ".join(keywords),
                "Score": 0,
                "Status": "ERROR",
                "Source": source,
                "Model": MODEL_NAME,
                "Release": RELEASE
            })

    fieldnames = [
        "Question_ID", "Question", "Expected_Answer", "LLM_Answer",
        "Matched_Keywords", "Missing_Keywords", "Score", "Status",
        "Source", "Model", "Release"
    ]
    with OUTPUT_FILE.open("w", newline="", encoding="utf-8-sig") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(results)

    passed = sum(row["Status"] == "PASS" for row in results)
    review = sum(row["Status"] == "REVIEW" for row in results)
    errors = sum(row["Status"] == "ERROR" for row in results)
    average = total_score / successful if successful else 0.0

    print("\n" + "=" * 58)
    print("              BASELINE EVALUATION SUMMARY")
    print("=" * 58)
    print(f"Student: Tejaswini")
    print(f"Release Version: {RELEASE}")
    print(f"Model: {MODEL_NAME}")
    print(f"Total Questions: {len(questions)}")
    print(f"Successful Responses: {successful}")
    print(f"Passed Questions: {passed}")
    print(f"Questions for Review: {review}")
    print(f"Failed Requests: {errors}")
    print(f"Average Keyword Coverage: {average:.2f}%")
    print(f"Evaluation Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"\nResults saved to: {OUTPUT_FILE.name}")
    print("BASELINE RUN COMPLETED!")
    print(f"Release {RELEASE} created successfully.")
    if args.demo:
        print("NOTE: This was an offline demonstration, not a live Llama 3.2 evaluation.")
    print("=" * 58)
    return 0


if __name__ == "__main__":
    sys.exit(main())
