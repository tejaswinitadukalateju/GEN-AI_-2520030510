import csv
import sys
from pathlib import Path

import torch
from transformers import AutoTokenizer, AutoModelForCausalLM

# WEEK 7: Next-token probabilities and Top-K candidates
# Student: Tejaswini

MODEL_NAME = "openai-community/gpt2"
TOP_K = 5
PROMPTS = [
    "The cat is",
    "Artificial intelligence is",
    "India is a",
    "Machine learning helps"
]
OUTPUT_CSV = Path(__file__).with_name("week7_probability_results.csv")


def main():
    print("=" * 65)
    print("       WEEK 7 - GENERATIVE AI PROGRAMMING PRACTICAL")
    print("                    Student: Tejaswini")
    print("=" * 65)
    print("\nLoading GPT-2 model...")
    print("The first run may take a few minutes to download GPT-2.")

    try:
        tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
        model = AutoModelForCausalLM.from_pretrained(MODEL_NAME)
        model.eval()
    except Exception as error:
        print("\nERROR: Could not load GPT-2.")
        print("Check your internet connection and try again.")
        print("Details:", error)
        return 1

    print("Model loaded successfully!")
    results = []

    for prompt in PROMPTS:
        print("\n" + "=" * 65)
        print("PROMPT:", prompt)
        print("=" * 65)

        inputs = tokenizer(prompt, return_tensors="pt")
        print("Input Token IDs:", inputs["input_ids"][0].tolist())

        try:
            with torch.inference_mode():
                outputs = model(**inputs)

            logits = outputs.logits[0, -1, :]
            probabilities = torch.softmax(logits, dim=-1)
            k = min(TOP_K, probabilities.numel())
            top_probs, top_ids = torch.topk(probabilities, k)

            print(f"\nTop {k} Next-Token Candidates:")
            print("-" * 55)

            for rank, (token_id, probability) in enumerate(
                zip(top_ids, top_probs), start=1
            ):
                token_id_value = token_id.item()
                token = tokenizer.decode([token_id_value])
                prob = probability.item()

                print(
                    f"Rank: {rank} | Token: {repr(token)} | "
                    f"Token ID: {token_id_value} | Probability: {prob:.6f}"
                )
                results.append([
                    prompt, rank, token, token_id_value, round(prob, 6)
                ])
        except Exception as error:
            print("Could not process this prompt:", error)

    try:
        with OUTPUT_CSV.open("w", newline="", encoding="utf-8-sig") as file:
            writer = csv.writer(file)
            writer.writerow([
                "Prompt", "Rank", "Candidate Token", "Token ID", "Probability"
            ])
            writer.writerows(results)
    except OSError as error:
        print("ERROR: Could not save CSV:", error)
        return 1

    print("\n" + "=" * 65)
    print("              EXECUTION SUMMARY")
    print("=" * 65)
    print("Student Name: Tejaswini")
    print("Model: GPT-2")
    print("Total Prompts:", len(PROMPTS))
    print("Top-K:", TOP_K)
    print("Total Candidate Results:", len(results))
    print("Results saved to:", OUTPUT_CSV.name)
    print("Program executed successfully!")
    print("=" * 65)
    return 0


if __name__ == "__main__":
    sys.exit(main())
