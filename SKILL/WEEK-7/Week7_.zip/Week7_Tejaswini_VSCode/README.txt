WEEK 7 - GENERATIVE AI PROGRAMMING PRACTICAL
Student: Tejaswini

Run in Windows VS Code:
1. Extract this ZIP and open the folder in VS Code.
2. Open Terminal > New Terminal.
3. Create and activate a virtual environment (recommended):
   py -m venv .venv
   .venv\\Scripts\\activate
4. Install dependencies:
   python -m pip install --upgrade pip
   python -m pip install -r requirements.txt
5. Run:
   python main.py

An internet connection is required on the first run to download GPT-2 from Hugging Face.
The program creates week7_probability_results.csv automatically.
