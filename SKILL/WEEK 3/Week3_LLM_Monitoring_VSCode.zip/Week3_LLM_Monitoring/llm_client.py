# llm_client.py
from abc import ABC, abstractmethod
import time

import requests
from google import genai
from google.genai import types

from cost_calculator import calculate_cost


class LLMProvider(ABC):
    @abstractmethod
    def generate(self, prompt):
        raise NotImplementedError


class GeminiProvider(LLMProvider):
    def __init__(self, api_key, model="gemini-3-flash-pro"):
        self.client = genai.Client(
            api_key=api_key,
            http_options=types.HttpOptions(timeout=30000),
        )
        self.model = model

    def generate(self, prompt):
        response = self.client.models.generate_content(
            model=self.model,
            contents=prompt,
        )

        usage = response.usage_metadata
        input_tokens = usage.prompt_token_count if usage else 0
        output_tokens = usage.candidates_token_count if usage else 0

        return {
            "response": response.text or "",
            "input_tokens": input_tokens or 0,
            "output_tokens": output_tokens or 0,
        }


class OllamaProvider(LLMProvider):
    def __init__(self, model="llama3.2"):
        self.model = model
        self.url = "http://localhost:11434/api/generate"

    def generate(self, prompt):
        response = requests.post(
            self.url,
            json={
                "model": self.model,
                "prompt": prompt,
                "stream": False,
            },
            timeout=120,
        )
        response.raise_for_status()
        data = response.json()

        return {
            "response": data.get("response", ""),
            "input_tokens": data.get("prompt_eval_count", 0),
            "output_tokens": data.get("eval_count", 0),
        }


class LLMClient:
    def __init__(self, provider, logger):
        self.provider = provider
        self.logger = logger

    def generate(self, prompt):
        max_attempts = 3
        start_time = time.perf_counter()
        last_error = None

        for attempt in range(1, max_attempts + 1):
            try:
                result = self.provider.generate(prompt)
                latency = round((time.perf_counter() - start_time) * 1000, 2)

                input_tokens = result["input_tokens"]
                output_tokens = result["output_tokens"]
                model = self.provider.model
                provider_name = type(self.provider).__name__

                log_data = {
                    "provider": provider_name,
                    "model": model,
                    "prompt": prompt,
                    "input_tokens": input_tokens,
                    "output_tokens": output_tokens,
                    "total_tokens": input_tokens + output_tokens,
                    "latency_ms": latency,
                    "cost": calculate_cost(
                        provider_name, model, input_tokens, output_tokens
                    ),
                    "attempts": attempt,
                    "status": "success",
                    "error": None,
                }

                try:
                    self.logger.log_call(log_data)
                except Exception as log_error:
                    print("MongoDB logging error:", log_error)

                return result["response"]

            except Exception as error:
                last_error = error
                retryable = isinstance(
                    error,
                    (
                        requests.exceptions.Timeout,
                        requests.exceptions.ConnectionError,
                    ),
                )

                status_code = getattr(error, "status_code", None)
                if status_code == 429 or (
                    isinstance(status_code, int) and status_code >= 500
                ):
                    retryable = True

                if not retryable or attempt == max_attempts:
                    break

                wait_time = 2 ** (attempt - 1)
                print(
                    f"Attempt {attempt} failed. "
                    f"Retrying in {wait_time} seconds..."
                )
                time.sleep(wait_time)

        latency = round((time.perf_counter() - start_time) * 1000, 2)
        failed_log = {
            "provider": type(self.provider).__name__,
            "model": self.provider.model,
            "prompt": prompt,
            "latency_ms": latency,
            "attempts": attempt,
            "status": "failed",
            "error": str(last_error),
        }

        try:
            self.logger.log_call(failed_log)
        except Exception as log_error:
            print("MongoDB logging error:", log_error)

        raise last_error
